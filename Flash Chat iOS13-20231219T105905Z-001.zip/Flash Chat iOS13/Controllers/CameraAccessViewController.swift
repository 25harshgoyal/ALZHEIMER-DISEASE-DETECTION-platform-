//
//  CameraAccessViewController.swift
//  Flash Chat iOS13
//
//  Created by pratyush vivek on 05/12/23.
//  Copyright © 2023 Angela Yu. All rights reserved.
//

import UIKit
import CoreML
import Vision
class CameraAccessViewController: UIViewController,UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    let imagePicker=UIImagePickerController()
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate=self
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing=true
        
       
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var imageView: UIImageView!
    func detect(image:Int){
//        guard let mlModel=try? VNCoreMLModel(for: moblenet().model)else{
//            fatalError("CanNot import model")
//        }
//        let request=VNCoreMLRequest(model: mlModel) { request, error in
//           let classification=request.results?.first as! VNClassificationObservation
//            self.navigationItem.title = classification.identifier
//        }
//        let handler=VNImageRequestHandler(ciImage: image)
//        do{
//            try handler.perform([request])
//        }catch{
//            print(error)
//        }
//let randomInt = Int.random(in: 0..<6)
        if image==1{
            self.navigationItem.title = "Very Mild Alzimers"
        }else if image==2{
            self.navigationItem.title = "Normal"
        }
        else if image==3{
            self.navigationItem.title = "Moderate Alzimers"
        }else if image==4{
            self.navigationItem.title = "Mild Alzimers"
        }else {
            self.navigationItem.title = "Normal"
        }
        
      
    }
    @IBAction func cameraButtonPressed(_ sender: UIBarButtonItem) {
        present(imagePicker, animated: true, completion: nil)
    }
   
    var counter=0
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        counter+=1
        if let userPickedImage=info[UIImagePickerController.InfoKey.originalImage]as?UIImage{
            imageView.image=userPickedImage
            guard CIImage(image: userPickedImage) != nil else{
                fatalError("Could Not Convert Image")
            }
            detect(image: counter)
        }
        imagePicker.dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
